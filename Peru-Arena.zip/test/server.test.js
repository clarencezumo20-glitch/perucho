'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createApp,blocked}=require('../server');
async function setup(t,options={}){
const app=createApp(options);await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));t.after(()=>app.close());
const base='http://127.0.0.1:'+app.server.address().port;
const post=async(route,data)=>{const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return {status:r.status,data:await r.json()}};
return {app,base,post};
}
test('10 amigos: sala llena, permisos, stream, salida y cambio de creador',async t=>{
const {app,base,post}=await setup(t);
const owner=(await post('create',{name:'Causa'})).data;
const players=[owner];
for(let i=1;i<10;i++){const r=await post('join',{name:'Amigo '+i,code:owner.code});assert.equal(r.status,200);players.push(r.data)}
assert.equal((await post('join',{name:'Once',code:owner.code})).status,409);
assert.equal((await post('start',{token:players[1].token})).status,403);
const abort=new AbortController();
const response=await fetch(base+'/api/events?token='+owner.token,{signal:abort.signal});
assert.equal(response.status,200);const reader=response.body.getReader();const chunk=await reader.read();const text=new TextDecoder().decode(chunk.value);assert.match(text,/"players"/);assert.match(text,/"timeLeft":180000/);assert.ok(!text.includes(owner.token));abort.abort();
assert.equal((await post('start',{token:owner.token})).status,200);
assert.equal((await post('join',{name:'Tarde',code:owner.code})).status,409);
const room=app.rooms.get(owner.code);assert.equal(room.state,'playing');assert.ok(room.endAt>Date.now()+178000);
assert.equal((await post('input',{token:owner.token,mx:'bad',my:0,angle:0})).status,400);
await post('leave',{token:owner.token});assert.equal(room.host,players[1].id);
assert.equal((await post('input',{token:owner.token,mx:0,my:0,angle:0})).status,401);
});
test('movimiento limitado, daño real, reaparición, fin exacto y revancha',async t=>{
let now=1000000;const {app,post}=await setup(t,{clock:()=>now,autoTick:false});
const one=(await post('create',{name:'Uno'})).data;
assert.equal((await post('start',{token:one.token})).status,409);
const two=(await post('join',{name:'Dos',code:one.code})).data;
await post('start',{token:one.token});const room=app.rooms.get(one.code),a=room.players.get(one.id),b=room.players.get(two.id);
a.x=100;a.y=100;b.x=220;b.y=100;a.shieldUntil=b.shieldUntil=0;
await post('input',{token:one.token,mx:10000,my:10000,angle:0});assert.ok(Math.hypot(a.input.mx,a.input.my)<=1.00001);
for(let shot=0;shot<4;shot++){
now+=240;await post('input',{token:one.token,mx:0,my:0,angle:0,fire:true});app.tick();
for(let step=0;step<5;step++){now+=33;app.tick()}
}
assert.equal(b.hp,0);assert.equal(a.kills,1);assert.equal(b.deaths,1);
now=b.respawnAt+1;app.tick();assert.equal(b.hp,100);assert.ok(!blocked(b.x,b.y));assert.ok(b.shieldUntil>now);
a.x=280;a.y=240;now+=50;await post('input',{token:one.token,mx:1,my:0,angle:0});app.tick();assert.equal(a.x,280,'la pared bloquea al jugador');
now=room.endAt-1;a.lastSeen=b.lastSeen=now;app.tick();assert.equal(room.state,'playing');now++;app.tick();assert.equal(room.state,'finished');assert.equal(room.bullets.length,0);
await post('start',{token:one.token});assert.equal(room.state,'playing');assert.equal(a.kills,0);assert.equal(b.deaths,0);assert.equal(room.endAt-now,180000);
});
test('rutas, origen, JSON y limpieza de salas inactivas',async t=>{
let now=100000;const {app,base,post}=await setup(t,{clock:()=>now,autoTick:false});
assert.equal((await fetch(base+'/')).status,200);assert.equal((await fetch(base+'/health')).status,200);
assert.equal((await post('join',{name:'Prueba',code:'XXXXXX'})).status,404);
assert.equal((await post('create',{name:'   '})).status,400);
assert.equal((await fetch(base+'/api/create',{method:'POST',headers:{Origin:'https://otro.test','Content-Type':'application/json'},body:'{}'})).status,403);
assert.equal((await fetch(base+'/api/create',{method:'POST',body:'bad json'})).status,400);
await post('create',{name:'Temporal'});now+=40001;app.tick();assert.equal(app.rooms.size,0);assert.equal(app.sessions.size,0);
});
test('10 conexiones simultáneas reciben el mismo inicio y fin de partida',async t=>{
let now=2000000;const {app,base,post}=await setup(t,{clock:()=>now,autoTick:false});
const first=(await post('create',{name:'Jugador 1'})).data,players=[first];
for(let i=2;i<=10;i++)players.push((await post('join',{code:first.code,name:'Jugador '+i})).data);
const controllers=players.map(()=>new AbortController());t.after(()=>controllers.forEach(c=>c.abort()));
const streams=await Promise.all(players.map(async(p,i)=>{
const res=await fetch(base+'/api/events?token='+p.token,{signal:controllers[i].signal});
assert.equal(res.status,200);const reader=res.body.getReader();let buffer='';
return {async next(){
while(true){const pos=buffer.indexOf('\n\n');if(pos>=0){const item=buffer.slice(0,pos);buffer=buffer.slice(pos+2);const data=item.split('\n').find(line=>line.startsWith('data: '));if(data)return JSON.parse(data.slice(6));continue}
const {value,done}=await reader.read();if(done)throw Error('Stream cerrado');buffer+=new TextDecoder().decode(value)}
}};
}));
for(const stream of streams){const s=await stream.next();assert.equal(s.players.length,10);assert.equal(s.state,'lobby')}
await post('start',{token:first.token});
for(const stream of streams){const s=await stream.next();assert.equal(s.state,'playing');assert.equal(s.timeLeft,180000)}
const room=app.rooms.get(first.code);now=room.endAt;for(const p of room.players.values())p.lastSeen=now;
app.tick();app.tick();
for(const stream of streams){const s=await stream.next();assert.equal(s.state,'finished');assert.equal(s.timeLeft,0);assert.equal(s.players.length,10)}
});
